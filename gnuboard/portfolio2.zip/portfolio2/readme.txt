Theme Name: portfolio2
Theme URI: http://theme.sir.kr/gnuboard5/demo/portfolio
Maker: SIR
Maker URI: http://sir.kr
Version: 1.0.0
Detail: 포트폴리오 테마는  SIR에서 제공하는 그누보드5 테마입니다. 부트스트랩을 사용하여 제작하였습니다. 포트폴리오 테마는 웹표준 및 접근성을 준수합니다.
License: GNU LESSER GENERAL PUBLIC LICENSE Version 2.1
License URI: http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html