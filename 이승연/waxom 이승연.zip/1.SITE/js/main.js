$(function(){
//슬라이드 관련 js
    $('.slider').each(function(){

        var $slideGroup = $('.slideshow-slide'),    //ul
            $slides =  $slideGroup.find('li'),      //ul>li
            slideCount = $slides.length,            // li 갯수
            currentIndex = 0;

            $slides.each(function(i){               // li 각각마다
                $(this).css({left:100*i+'%'});      //sludes 각각 left 가로정렬
             }) ;

            function gotoSlide(index){              // 슬라이드 이동하기
                $slideGroup.stop(true).animate({left:-100*index+'%'},500);
                currentIndex = index;
                }   
              setInterval(function(){
                  var nextIndex = (currentIndex+1)%slideCount;
                  gotoSlide(nextIndex);
              },3000)
 
    });

    //
    var $header = $('header');
    $(window).scroll(function(){
        var $currentSct = $(this).scrollTop();

        if($currentSct > 0){
            $header.addClass('sticky');
        }else{
            $header.removeClass('sticky');
        };
    });

    //video
    $('.video .icon').click(function(e){
        e.preventDefault();
        $('#overlay').addClass('visible');
    

        //자동재생
        var currentUrl = $('iframe').attr('src');
        var newStr = '?autoplay=1';
        var newUrl = currentUrl.concat(newStr);

        console.log(newUrl);

        $('iframe').attr('src', newUrl);
        
    });
    $('.video .close').click(function(e){
        e.preventDefault();
        $('#overlay').removeClass('visible');
        //끄면다시처음으로시작하는
        $(this).siblings('iframe').attr('src',$('iframe').attr('src'));

    });

    $('.posts_list').bxSlider({
        //옵션값
        //mode : 'vertical'/speed : 500
        minSlides : 1,
        maxSlides : 3,
        moveSlides : 1,
        slideWidth : 370,
        slideMargin : 30,
        pager : false,
        prevSelector : '.controls .prev',
        nextSelector : '.controls .next',
        
    });

});//end ready

