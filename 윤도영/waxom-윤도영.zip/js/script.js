$(function(){
   
    //슬라이드 관련 js
    $('.slider').each(function(){
        var $sliderGroup=$('.slideshow-slide'),
             $slides=$sliderGroup.find('li'),
             slideCount=$slides.length,
             currentIndex=0;

        //slides 각각 left 가로로 정렬
        $slides.each(function(i){
            $(this).css({left:100*i+'%'});
        });

        function gotoSlide(index){
            $sliderGroup.stop(true).animate({left:-100*index+'%'},500);
            currentIndex=index;
        }
        setInterval(function(){
            var nextIndex=(currentIndex+1)%slideCount;
            gotoSlide(nextIndex);
        },5000)

        
        
    }); //slide

    //스크롤 이동 하면 sticky 추가
    var $header = $('header');
        $(window).scroll(function(){
            var $currentScr = $(this).scrollTop();
            if($currentScr > 0){
                $header.addClass('sticky');
            }else{
                $header.removeClass('sticky');
            };
        });

    
    //video  .overlay
    $('.video .icon').click(function(e){
        e.preventDefault();
        $('#overlay').addClass('visible');

        //자동재생
        var currentUrl = $('iframe').attr('src');
        var newStr = '?autoplay=1';
        var newUrl =currentUrl.concat(newStr);
        //console.log(newUrl);

        $('iframe').attr('src',newUrl);

    });
    $('.video .close').click(function(e){
        e.preventDefault();
        $('#overlay').removeClass('visible');
        //끄면, 다시 처음으로 시작하는
        $(this).siblings('iframe').attr('src',$('iframe').attr('src'));
    });

    $('.recentPost_list').bxSlider({
        // mode:'vertical',
        minSlides:1,
        maxSlides:3,
        moveSlides:1,
        slideWidth: 370,
        // adaptiveHeight:true,
        slideMargin: 30,
        pager : false,
        nextSelector: '.controls .next',
        prevSelector: '.controls .prev'
      });

});