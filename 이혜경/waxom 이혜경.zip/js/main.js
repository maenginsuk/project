$(function(){
    $('.nav>li').mouseenter(function(){
        $(this).find('.submenu').stop(true).slideDown();
    })
    .mouseleave(function(){
        $(this).find('.submenu').stop().slideUp();
    });
    //메인이미지 ㅡ슬라이드
    //변수선언
    var slideGroup=$('#imgslide .imgs'),
        slides=slideGroup.find('.slide'),
        slideCount=slides.length,
        currentCount=0;
    //slide의 left 값을 셋팅 <-- css 에서 셋팅
    slides.each(function(i){
        $(this).css({left:100*i+'%'})
    });
    //슬라이드 5초마다 이미지가 오른쪽 이동 <--setInterval(할일,시간)
    function gotoSlide(index){
        slideGroup.animate({left:-100*index+'%'},500);
    }
    //gotoSlide(1);
    var timer;
    function startTimer(){
        timer=setInterval(function(){
            var nextIndex=(currentCount + 1)%slideCount;
            gotoSlide(nextIndex);
        },5000)
    }
    startTimer();

    //레이어 팝업
    $('.layerPopup').click(function(){
        $('.layer').show();
    });
    $('.layer .close').click(function(){
        $('.layer').hide();
    });

});  //문서로딩