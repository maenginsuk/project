$(function(){

    //스크롤 이벤트

    var $sectionOffset02    =   $('.section02').offset().top,
        $sectionOffset05    =   $('.section05').offset().top;

    $('.scrollDown').click(function(ev){
        ev.preventDefault();
        $('html, body').animate({scrollTop : $sectionOffset02 }, 700); 
    });

    $('.goTop').click(function(ev){
        ev.preventDefault();
        $('html, body').animate({scrollTop : 0 }, 700); 

    });


    var depth1 = $('.depth1').children('li');

    depth1.mouseenter(function(){   
        depth1.removeClass('hover');
        $(this).addClass('hover');
    }).mouseleave(function(){
        $(this).removeClass('hover');        
    })


    
    var thisexcuted =true;

    $('.gnb_menu > ul').find('li').eq(2).click(function(){
        if(thisexcuted == true){
            $(this).find('ul').slideDown();
            thisexcuted = false;
            $(this).find('i').removeClass('fa-caret-down');
            $(this).find('i').addClass('fa-caret-up');

        }else if(thisexcuted == false){
            $(this).find('ul').slideUp();
            thisexcuted =true;
            $(this).find('i').removeClass('fa-caret-up');
            $(this).find('i').addClass('fa-caret-down');
        }
    })



    $(window).scroll(function(ev){
        ev.preventDefault();
        var currentScr = $(this).scrollTop(),
            $fixBanner = $('.fixBanner');

        //console.log('scr : '+currentScr );
        if(currentScr < 100){
            $fixBanner.slideUp();
        }else if(currentScr >= $fixBanner.outerHeight() && currentScr < $sectionOffset05*0.85){
            $fixBanner.slideDown('fast');
            $fixBanner.css({
                'position':'fixed',
                opacity : 0.9
            });
        }else if(currentScr >= $sectionOffset05*0.85){
            $fixBanner.css({
                'position':'relative'
            });
        };

        
    });



    //슬라이드 이벤트


    var $sliderGroup = $('.sliderGroup'),
        $slider     =   $sliderGroup.find('li'),
        $sliderCnt  =  $slider.length,
        currentCnt  =   0,
        timer,
        $mainTitle = $('.mainTitle'),
        $indicator = $('.indicator'),
        $control   = $indicator.find('strong'),
        $duration   = 5000,
        excuted = true;

        $slider.each(function(idx){
            $(this).css({
                left:idx*100+'%'
            });
        });
         


        function goSlider(i){
            var duration = 700;
            if(i < 1){
                duration = 100;
            }
            $sliderGroup.stop().animate({
                left:i*-100+'%'
            },duration);
            currentCnt = i;
            colorChange(i);
            changeTitle(i);
        };

        function startTimer(){
            timer = setInterval(function(){
                var nextCnt = (currentCnt +1)%$sliderCnt;
                goSlider(nextCnt);
            },$duration);
        };

        
        function stopTimer(){                   //타이머 멈춤
            clearInterval(timer);    
        };

        //indicator        
        function colorChange(j){
            $indicator.find('span').removeClass('active');
            $indicator.find('span').removeClass('progressBar');
            $indicator.find('span').eq(j).addClass('active');
            if(excuted==true){
                $indicator.find('span').eq(j).addClass('progressBar');
            }
            progressBar()
        }

        function progressBar(){
            $indicator.find('.progressBar').stop().animate({
                marginRight : 80+'px'
            },300);
            $indicator.find('.progressBar').siblings('span').stop().animate({
                marginRight : 0
            },300);
        }
        

        $control.click(function(){
            if (excuted==true){ //play중이면 true
                stopTimer();
                $(this).find('i').removeClass('fa-play');
                $(this).find('i').addClass('fa-pause');
                $indicator.find('span').removeClass('progressBar');
                $indicator.find('span').css({marginRight:0});
                excuted = false;
            }else{
                excuted= true;
                startTimer();
                $(this).find('i').removeClass('fa-pause');
                $(this).find('i').addClass('fa-play');
                var i = $indicator.find('.active').index();
                colorChange(i);

            }
        });
        $indicator.find('span').click(function(){
            var index = $(this).index();
            goSlider(index);
        });
        

        //title 바뀜

        function changeTitle(idx){
            $mainTitle.stop().animate({top:20+'%', opacity:0});
            $mainTitle.eq(idx).stop().animate({
                top:10+'%', opacity:1
            },700);
        };

        changeTitle(0);
        colorChange(0);
        startTimer();

        var clickExcuted = true;

        $('.quickMenu').find('.numbers').click(function(){
            if(clickExcuted == true){
                $('.telNumber').slideDown();
                clickExcuted=false;
            }else{
                $('.telNumber').slideUp();
                clickExcuted=true;
            };
        });

        //arrowBox main

        $('.arrowBox').find('p').eq(0).click(function(){
            var index = $indicator.find('.active').index(),
                nextIndex = (index+1)%$sliderCnt;
                goSlider(nextIndex);
        });
        $('.arrowBox').find('p').eq(1).click(function(){
            var index = $indicator.find('.active').index(),
                nextIndex = (index-1)%$sliderCnt;
                if(nextIndex <0 ){
                    nextIndex = $sliderCnt -1;
                };
                goSlider(nextIndex);

        });


        //시간에 따라 의료진 다르게 하기

        var doctorsGroup     = $('.doc').find('ul'),
            doctorsCnt     = doctorsGroup.length,
            currentPage =  0,
            setTimes;

        doctorsTimer();
        function doctorsTimer(){
            setTimes = setInterval(function(){
                var nextDoctor = (currentPage+1)%doctorsCnt;
                goDoctors(nextDoctor);
            }, 7000);
        };
        function doctorStop(){
            clearInterval(setTimes);
        };
        function goDoctors(j){
            doctorsGroup.removeClass('visiable-list');
            doctorsGroup.eq(j).addClass('visiable-list');
            currentPage = j;
            changeDocColor(j);
            leftRight();
        };
        function changeDocColor(j){
            $('.msg').find('li').removeClass('active');
            $('.msg').find('li').eq(j).addClass('active');
        };

        $('.msg').find('li').click(function(){
            var index = $(this).index();
            goDoctors(index);     
            leftRight();           
            
        });

        //의료진 li의 width를 구해서 그만큼 margin으로 이동
        leftRight();
        function leftRight(){
            if($('.visiable-list').find('li').length>3){
                $('.doctors > div').removeClass('moveBox');
                $('.doctors > div').addClass('moveBox');
                console.log('333333');
            }else{
                $('.doctors > div').removeClass('moveBox');
            }
        };
        $('.doctors').mouseenter(function(){
            if($('.visiable-list').find('li').length>3){
                $(this).find('.doc > ul').stop().animate({
                    marginLeft:-100+'px'
                },700);
            }
            doctorStop();
        }).mouseleave(function(){
            if($('.visiable-list').find('li').length>3){
                $(this).find('ul').stop().animate({
                    marginLeft:0
                },1700);
            }
            doctorsTimer();
        })

        //의료진 indicator02

        var indicator02 = $('.indicator02');
        indicator02.find('p').mouseenter(function(){
            doctorStop();
        }).mouseleave(function(){
            doctorsTimer();
        })

        indicator02.find('p').eq(0).click(function(){
            var idx = $('.visiable-list').index(),
                nxtIdx = (idx+1)%doctorsCnt;
            goDoctors(nxtIdx);
        });
        indicator02.find('p').eq(1).click(function(){
            var idx = $('.visiable-list').index(),
                nxtIdx = (idx-1)%doctorsCnt;
                if(nxtIdx < 0){
                    nxtIdx = doctorsCnt -1;
                }
            goDoctors(nxtIdx);
        });





        // centers 슬라이드
        // 8개인데 8 다음페이지가 1로 안됨....

        var $center = $('.centerLst').find('li'),
            $firstPage = $('.centerLst').find('li:first-of-type'),
            $lastPage   =   $('.centerLst').find('li:last-of-type'),
            centers    =   8,
            $centerTimer,
            $thisPage = 0;


        function centerSlideTimer(){
            $centerTimer = setInterval(function(){
                var nextCenter = ($thisPage +1)%centers;
                goCenters(nextCenter);
            },3000);
        };
        centerSlideTimer();

        function stopCenterSlide(){
            clearInterval($centerTimer);
        };

        function goCenters(idx){
            var $thisCenter = 'centerPic0'+(idx+1),
                $nxtCenter  =  'centerPic0'+(idx+2);
            if(idx == 7){
                $nxtCenter  = 'centerPic01';
            }
                
            $('.centers').find('li').removeClass('active');
            $('.centerName').find('li').removeClass('active');
            $('.centerExplain').find('li').removeClass('active');

            $('.centers').find('li').eq(idx).addClass('active');
            $('.centerName').find('li').eq(idx).addClass('active');
            $('.centerExplain').find('li').eq(idx).addClass('active');
            $center.removeClass();
            $firstPage.addClass($thisCenter);
            $lastPage.addClass($nxtCenter);
            $thisPage =idx;
        };

        $('.centerExplain').mouseenter(function(){
            stopCenterSlide();
        }).mouseleave(function(){
            centerSlideTimer();
        });


        $('.centers').find('li').click(function(){
            var i = $(this).index();
            goCenters(i);
        });

        $('.centerTxt .arrowsBox').find('span').eq(0).click(function(){
            var j = $('.centerName').find('.active').index();
            var nxt = (j-1)%centers
            goCenters(nxt);
        });
        $('.centerTxt .arrowsBox').find('span').eq(1).click(function(){
            var j = $('.centerName').find('.active').index();
            var nxt = (j+1)%centers
            goCenters(nxt);
        });
        




        





        //section04 bttn readMore Event
        var newsHeight = $('.newses').find('li').outerHeight();
        $('.readMore').click(function(){
            $('.section04').stop().animate({
                height:960 + newsHeight +'px'
            },700);
            $('.newses').find('li').slideDown();
            $(this).css({opacity:0});
        });
});