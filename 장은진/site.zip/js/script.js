$(function(){

    //스크롤 이벤트

    var $sectionOffset02    =   $('.section02').offset().top,
        $sectionOffset03    =   $('.section03').offset().top,
        $sectionOffset04    =   $('.section04').offset().top,
        $sectionOffset05    =   $('.section05').offset().top,
        $lastScroll         =   $('footer').offset().top;



    $('.scrollDown').click(function(ev){
        ev.preventDefault();
        $('html, body').animate({scrollTop : $sectionOffset02 }, 700); 
    });

    $('.goTop').click(function(ev){
        ev.preventDefault();
        $('html, body').animate({scrollTop : 0 }, 700); 

    })

    var scrollEvent = 'false',
        count = 0;

    $('html, body').on('mousewheel',function(ev){
        ev.preventDefault();
        var $wheel = ev.originalEvent.wheelDelta,
            $winHeight = $('.wrap').outerHeight();

            if($wheel > 1 && scrollEvent == false &&count>=1){
                console.log(scrollEvent + ' : '+count);

                scrollEvent = true;
                count -- ;
                $('html, body').stop().animate({
                    scrollTop:$winHeight*count
                },{duration: 300, complete:function(){
                    scrollEvent = flase;
                }});
            }else if($wheel <3 && scrollEvent == false && count <3){
                console.log('2222 '+count);
                count ++;
                $('html, body').stop().animate({
                    scrollTop : $winHeight * count
                },{duration : 300, complete : function(){
                    scrollEvent = flase;
                }});

            };

    });





    //슬라이드 이벤트


    var $sliderGroup = $('.sliderGroup'),
        $slider     =   $sliderGroup.find('li'),
        $sliderCnt  =  $slider.length,
        currentCnt  =   0,
        timer,
        $mainTitle = $('.mainTitle'),
        $indicator = $('.indicator'),
        $control   = $indicator.find('strong'),
        excuted = true;

        $slider.each(function(idx){
            $(this).css({
                left:idx*100+'%'
            });
        });
         


        function goSlider(i){
            $sliderGroup.stop().animate({
                left:i*-100+'%'
            },700);
            currentCnt = i;
            colorChange(i);
            changeTitle(i);
        };

        function startTimer(){
            timer = setInterval(function(){
                var nextCnt = (currentCnt +1)%$sliderCnt;
                goSlider(nextCnt);
            },5000);
        };

        
        function stopTimer(){                   //타이머 멈춤
            clearInterval(timer);    
        };

        //indicator        
        function colorChange(j){
            $indicator.find('span').removeClass('active');
            $indicator.find('span').removeClass('progressBar');
            $indicator.find('span').eq(j).addClass('active');
            if(excuted==true){
                $indicator.find('span').eq(j).addClass('progressBar');
            }
            progressBar()
        }

        function progressBar(){
            $indicator.find('.progressBar').stop().animate({
                marginRight : 80+'px'
            },300);
            $indicator.find('.progressBar').siblings('span').stop().animate({
                marginRight : 0
            },300);
        }
        
        $indicator.find('span').click(function(){
            var index = $(this).index();
            goSlider(index);
        });
        

        $control.click(function(){
            if (excuted==true){ //play중이면 true
                stopTimer();
                $(this).find('i').removeClass('fa-play');
                $(this).find('i').addClass('fa-pause');
                $indicator.find('span').removeClass('progressBar');
                $indicator.find('span').css({marginRight:0});
                excuted = false;
            }else{
                excuted= true;
                startTimer();
                $(this).find('i').removeClass('fa-pause');
                $(this).find('i').addClass('fa-play');
                var i = $indicator.find('.active').index();
                colorChange(i);

            }
        });

        //title 바뀜

        function changeTitle(idx){
            $mainTitle.stop().animate({top:20+'%', opacity:0});
            $mainTitle.eq(idx).stop().animate({
                top:10+'%', opacity:1
            },700);
        };

        changeTitle(0);
        colorChange(0);
        startTimer();

        var clickExcuted = true;

        $('.quickMenu').find('.numbers').click(function(){
            if(clickExcuted == true){
                $('.telNumber').slideDown();
                clickExcuted=false;
            }else{
                $('.telNumber').slideUp();
                clickExcuted=true;
            };
        });
        


        //의료진 li의 width를 구해서 그만큼 margin으로 이동



        //section04 bttn readMore Event
        var newsHeight = $('.newses').find('li').outerHeight();
        $('.readMore').click(function(){
            $('.section04').stop().animate({
                height:960 + newsHeight +'px'
            },700);
            $('.newses').find('li').slideDown();
            $(this).css({opacity:0});
        })
});