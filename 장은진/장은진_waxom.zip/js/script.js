$(function(){
	
    //슬라이드
    var $slideGroup = $('.slideShow-slide'),
        $slide = $('.slide'),
        $slideCnt = $slide.length,
        currentCnt = 0,
        timer;

        $slide.each(function(i){
            $(this).css({
                left:i*100+'%'
            });
        });

        function gotoSlide(idx){
            $slideGroup.stop().animate({
                left:idx*-100+'%'
            },500);
            currentCnt = idx;
            changeColor(currentCnt);
        };

        function startTimer(){
            timer = setInterval(function(){
                var nextCnt = (currentCnt+1)%$slideCnt;
                gotoSlide(nextCnt);
            },4000);
        };
        startTimer();

        function stopTimer(){                   //타이머 멈춤
            clearInterval(timer);    
        };

        $('slider').on({                             //슬라이드 위에 있을 때 타이머 멈춤
            mouseenter : stopTimer,
            mouseleave : startTimer
        });
    //control
        var $prev = $('.prev a'),
            $next = $('.next a');

            $prev.click(function(){                               
                var prevIdx = (currentCnt-1)%$slideCnt;
                if(prevIdx < 0){
                    gotoSlide($slideCnt-1);
                }else{
                    gotoSlide(prevIdx);
                }
            });
            $next.click(function(){  
                var nxtIdx = (currentCnt+1)%$slideCnt;
                gotoSlide(nxtIdx);
            });


  
    //indicator
        var $indicatorGroup = $('.indicator'),
            $indicator = $indicatorGroup.find('span'),//?왜안되지
            $currentPage = 0;


        $indicator.click(function(){
            /* $indicator.removeClass('active');
            $(this).addClass('active'); */
            $currentPage = $(this).index();
            gotoSlide($currentPage);
            changeColor($currentPage);

        });
        function changeColor(j){
            $indicatorGroup.find('span').removeClass('active');
            $indicatorGroup.children().eq(j).addClass('active');
            // console.log('2222')
        };


    //header scroll top
    var $header = $('header');
    $(window).scroll(function(){
        var $currentSct = $(this).scrollTop();

        if($currentSct > 0){
            $header.addClass('sticky');
        }else{
            $header.removeClass('sticky');
        };
        
        //scrollTop services 나오는 이벤트

        console.log($currentSct);

        if($currentSct >=200 ){
            $('.services').stop().animate({
                opacity:1
            },450);
        };

  
    });


    //project 영역내 hover

    var $titleLst = $('.titleLst'),
        $seletedTitle = $titleLst.find('div'),
        $projectLst = $('.projectList'),
        $seletedLst = $projectLst.find('li');

    $seletedTitle.mouseenter(function(){
        $seletedTitle.removeClass('selected');
        $(this).addClass('selected');
    }).mouseleave(function(){
        $seletedTitle.removeClass('selected');
    });

    $seletedTitle.click(function(ev){
        ev.preventDefault();
        $(this).trigger('mouseenter');

        var index = $(this).index();
        //console.log('idx :: '+index);

        // 인덱스 넘버링에 따라 프로젝트 리스트 내에 li들의 해당되는 클래스만 움직임
        
        if(index==0){            
            //console.log('aaaa');
            $seletedLst.fadeIn();
        }
        if(index==1){
            $seletedLst.hide();
            $projectLst.find('.web').fadeIn();
        }
        if(index==2){
            $seletedLst.hide();
            $projectLst.find('.mo').fadeIn();
        }
        if(index==3){
            $seletedLst.hide();
            $projectLst.find('.illustration').fadeIn();

        }
        if(index==4){
            $seletedLst.hide();
            $projectLst.find('.photography').fadeIn();
        }
    });


    $seletedLst.mouseenter(function(){
        $seletedLst.removeClass('select');
        $(this).addClass('select');
    });


    //비디오 팝업
    var $videoPopup = $('.videoPresentation').find('.videoPopup');

    $('.videoPresentation').find('.iconPlay').click(function(ev){
        ev.preventDefault();
        $videoPopup.fadeIn();
    });

    $videoPopup.find('.close').click(function(ev){
        ev.preventDefault();
        $videoPopup.fadeOut('slow');
        $(this).siblings('iframe').attr('src', $('iframe').attr('src'));
    });
    

    //recentPost 첫번째 라디오버튼 작업

    var $indicator = $('.photoBox').find('.indicators'),
        $cheked =   $indicator.find('span'),
        $photos =   $('.photoBox').find('.photos');

    $cheked.click(function(){   
        var idx = $(this).index();        
        $cheked.removeClass('checked');
        $(this).addClass('checked');
        console.log(idx);

        $photos.find('li').hide();
        $photos.find('li').eq(idx).fadeIn();
    });        
    
    var $counterExecuted = true;

    $(window).scroll(function(){
        var $currentScroll = $(window).scrollTop();

        if ($counterExecuted==true){
            if($currentScroll>3780){
                var counters = [3587, 207, 2500, 873, 900],
                    cntlength = counters.length;
                
                for(var i=0; i<cntlength;i++){
                    countersNumber(i+1, counters[i]);
                };
                $counterExecuted = false;
            };

        };
        
        function countersNumber(i, j){            
            var counterli = $('.counters >li:nth-of-type('+i+')').find('p:first-of-type');
            $({val:0}).animate({val:j},{
                duration:2000,
                step:function(){
                    var number = Math.floor(this.val);
                    counterli.text(number);
                },complete:function(){
                    var number = Math.floor(this.val);
                    counterli.text(number);
                }
            });

        };
    });       
    






});


