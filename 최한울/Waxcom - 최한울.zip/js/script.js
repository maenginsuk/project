
$(function(){ 


    var $slideUl = $('.slideshow-slide'),
        $slideLi = $('.slideshow-slide>li').length;
    var currentCount = 0;

     function gotoSlide(idx){
        var asd = -100 * idx + "%";
        $slideUl.animate({left: -100 * idx + "%"}, 2000);
        currentCount = idx;
    }

    function move(){
        setInterval(function(){
            var nextIndex = (currentCount + 1) % $slideLi;
            // console.log(nextIndex);
            gotoSlide(nextIndex);
        },4000)
    }
    move();   

    var header = $('header');
    $(window).scroll(function(){
        var currentScroll = $(this).scrollTop();
        if (0 < currentScroll){
            header.addClass('sticky');
        } else{
            header.removeClass('sticky');
        }
    })


      $('.recentPost_inner_ul').bxSlider({
          //옵션 : 옵션값
        //   mode : 'vertical'
        minSlides : '1',
        maxSlides : '3',
        moveSlides : 1,
        slideWidth : 370,
        slideMargin : 30,
        pager : false,
        nextSelector : '.controls .next',
        prevSelector : '.controls .prev'
      });


});